<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/style/style.css">
    <title>Home | Continuous integration</title>
</head>

<body>
    <?= $this->include('layout/navbar'); ?>

    <div class="section">
        <div class="container">
            <div class="box-home">
                <div class="landing-img">
                    <img src="<?php echo base_url(); ?>/images/office.jpg" alt="" width="450px">
                </div>
                <div class="landing-desc">
                    <h2>PT. Techtok</h2><br>
                    <p>Sebuah Perusahaan yang bergerak di bidang IOT. <br>
                        Memberikan layanan dan fasilitas kebutuhan IOT
                    </p>
                </div>
            </div>
        </div>
    </div>
    <div class="section">
        <div class="container">
            <div class="box">
                <h1>IOT Device</h1><br>
                <div class="row-img">
                    <?php
                    foreach ($tabel as $t) {
                    ?>
                        <div class="row-content">
                            <img src="/images/<?php echo $t['image'] ?>" alt="" width="250px" height="250px">
                            <h4><?php echo $t['nama'] ?></h4>
                        </div>
                    <?php
                    }
                    ?>

                </div><br>
                <center>
                    <a href="/pages/device"><button id="device-button">Detail</button></a>
                </center>
            </div>
        </div>
    </div>
</body>

</html>