<?php
$fetch_id = $_GET['id'];

foreach ($tabel as $t) :
    if ($t['id'] == $fetch_id) {
        $device_image = $t['image'];
        $device_name = $t['nama'];
        $device_qty = $t['quantity'];
    }
endforeach;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/style/style.css">
    <title>Detail | Continuous integration</title>
</head>

<body>
    <?= $this->include('layout/navbar'); ?>

    <div class="section">
        <div class="container">
            <h1>Detail Barang</h1><br>
            <div class="box">
                <center>
                    <img src="/images/<?php echo $device_image ?>" alt="" width="200px"><br>
                    <h1><?php echo $device_name ?></h1><br>
                    <h3>Quantity : <?php echo $device_qty ?></h3><br>
                    <a href="/pages/device"><button id="button-action">Back To Home</button></a>
                </center>

            </div>
        </div>
    </div>
</body>

</html>