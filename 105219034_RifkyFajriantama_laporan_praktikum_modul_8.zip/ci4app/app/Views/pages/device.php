<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/style/style.css">
    <title>Device | Continuous integration</title>
</head>

<body>
    <?= $this->include('layout/navbar'); ?>

    <div class="section">
        <div class="container">
            <div class="box">
                <h1>Daftar Barang</h1><br>
                <table cellspacing="0" class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Image</th>
                            <th>ID</th>
                            <th>Device Name</th>
                            <th>Device Brand</th>
                            <th>Quantity</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $i = 1;
                        foreach ($tabel as $t) :
                        ?>
                            <tr>
                                <td>
                                    <center><?php echo $i++ ?></center>
                                </td>
                                <td>
                                    <center><img src="/images/<?php echo $t['image'] ?>" alt="" width="80px"></center>
                                </td>
                                <td><?= $t['id'] ?></td>
                                <td><?= $t['nama'] ?></td>
                                <td><?= $t['brand'] ?></td>
                                <td>
                                    <center><?= $t['quantity'] ?></center>
                                </td>
                                <td>
                                    <center><?= $t['status'] ?></center>
                                </td>
                                <td>
                                    <center>
                                        <a href="/pages/detail?id=<?php echo $t['id'] ?>"><button id="button-action">Detail</button></a>
                                    </center>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                    <tbody>
                        <tr>

                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>

</html>