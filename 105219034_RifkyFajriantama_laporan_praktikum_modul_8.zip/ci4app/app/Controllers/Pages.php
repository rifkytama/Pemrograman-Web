<?php

namespace App\Controllers;

class Pages extends BaseController
{
    public function index()
    {
        $data = [
            'title' => 'Home | Monitoring IOT',
            'tabel' => [
                [
                    'id' => '12345',
                    'nama' => 'Arduino',
                    'brand' => 'Uno Ardui',
                    'quantity' => '4',
                    'image' => 'arduino.jpeg',
                    'status' => '0'
                ],
                [
                    'id' => '67890',
                    'nama' => 'Graphic Cards',
                    'brand' => 'Nvidia Geforce RTX',
                    'quantity' => '6',
                    'image' => 'vga.jpeg',
                    'status' => '1'
                ],
                [
                    'id' => '98760',
                    'nama' => 'Headphone ROG',
                    'brand' => 'Asus',
                    'quantity' => '9',
                    'image' => 'headphone.jpeg',
                    'status' => '1'
                ],
                [
                    'id' => '543221',
                    'nama' => 'Keyboard RGB',
                    'brand' => 'Steelseries',
                    'quantity' => '8',
                    'image' => 'keyboard.jpeg',
                    'status' => '1'
                ]
            ]
        ];

        return view('pages/home', $data);
    }

    public function device()
    {
        $data = [
            'title' => 'Home | Monitoring IOT',
            'tabel' => [
                [
                    'id' => '12345',
                    'nama' => 'Arduino',
                    'brand' => 'Uno Ardui',
                    'quantity' => '4',
                    'image' => 'arduino.jpeg',
                    'status' => '0'
                ],
                [
                    'id' => '67890',
                    'nama' => 'Graphic Cards',
                    'brand' => 'Nvidia Geforce RTX',
                    'quantity' => '6',
                    'image' => 'vga.jpeg',
                    'status' => '1'
                ],
                [
                    'id' => '98760',
                    'nama' => 'Headphone ROG',
                    'brand' => 'Asus',
                    'quantity' => '9',
                    'image' => 'headphone.jpeg',
                    'status' => '1'
                ],
                [
                    'id' => '543221',
                    'nama' => 'Keyboard RGB',
                    'brand' => 'Steelseries',
                    'quantity' => '8',
                    'image' => 'keyboard.jpeg',
                    'status' => '1'
                ]
            ]
        ];
        return view('pages/device', $data);
    }

    public function detail()
    {
        $data = [
            'title' => 'Home | Monitoring IOT',
            'tabel' => [
                [
                    'id' => '12345',
                    'nama' => 'Arduino',
                    'brand' => 'Uno Ardui',
                    'quantity' => '4',
                    'image' => 'arduino.jpeg',
                    'status' => '0'
                ],
                [
                    'id' => '67890',
                    'nama' => 'Graphic Cards',
                    'brand' => 'Nvidia Geforce RTX',
                    'quantity' => '6',
                    'image' => 'vga.jpeg',
                    'status' => '1'
                ],
                [
                    'id' => '98760',
                    'nama' => 'Headphone ROG',
                    'brand' => 'Asus',
                    'quantity' => '9',
                    'image' => 'headphone.jpeg',
                    'status' => '1'
                ],
                [
                    'id' => '543221',
                    'nama' => 'Keyboard RGB',
                    'brand' => 'Steelseries',
                    'quantity' => '8',
                    'image' => 'keyboard.jpeg',
                    'status' => '1'
                ]
            ]
        ];
        return view('pages/detail', $data);
    }
}
